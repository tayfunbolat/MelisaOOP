﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MelisaKalpTayfunSOLID.InterfaceSegregation
{
    //Interface Segregation Principle : Interface de verilecek yapıları alt sınıf kullanmak zorunda, eğer kullanmıyorsa ayır.
    public class Araba
    {
        public string Yil { get; set; } //Property
        public int Model { get; set; }
    }


    public class AracHareketleri
    {
        //readonly tanımı olduğunda sadece contructor üzerinde setleme yapılır.
        private readonly Araba araba; //Field

        public AracHareketleri(Araba araba /*Dependecy inversion*/)
        {
            this.araba = araba;
            
        }

        /*Depency inversion yapılmazsa her bir marka araba üretildiğinde onun için özel bir method yazmak gerekir.*/
        //public AracHareketleri(Ferrari araba /*Dependecy inversion*/)
        //{
        //    this.araba = araba;


        //}
        //public AracHareketleri(Tofas araba /*Dependecy inversion*/)
        //{
        //    this.araba = araba;

        //}
        public int HareketEttir()
        {
            if (araba is Ferrari ferrari) //1.yöntem
            {
                //var ferrari1 = araba as Ferrari; 2.yöntem
                ferrari.NitroModAktifEt();
                return ferrari.GazaBas();
                
                //((Ferrari)araba).NitroModAktifEt();// cast işlemi yapar  3.yöntem
                //return
                //     ((Ferrari)araba).GazaBas();
            }
            if (araba is Tofas tofas)
            {
                tofas.vitesDegistir();
                return tofas.GazaBas();
                //((Tofas)araba).vitesDegistir();
                //return ((Tofas)araba).GazaBas();
            }
            return 0;
        }

    }
}
