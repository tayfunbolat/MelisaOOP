﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MelisaKalpTayfunSOLID.InterfaceSegregation
{
    public class Ferrari : Araba, IHizlanabilme, INitro
    {
        public int GazaBas()
        {
            return 350;
        }

        public bool NitroModAktifEt()
        {
            return true;
        }
    }
}
