﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MelisaKalpTayfunSOLID.InterfaceSegregation
{
    public class Tofas : Araba, IHizlanabilme, IVitesArttir
    {
        public int GazaBas()
        {
            return 50;
        }

        public int vitesDegistir()
        {
            return 5;
        }
    }
}
