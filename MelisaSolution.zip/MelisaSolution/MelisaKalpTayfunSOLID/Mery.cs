﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MelisaKalpTayfunSOLID
{
    //Single Responsibility : Her bir yapı veya class veya method tek bir görevi yeni getirsin
    public class Mery
    {
        public int Age { get; set; } //Property
        public string Type { get; set; }
        public int Weight { get; set; }
    }

    public class MeryHareketleri:IAgacaTirman
    {
        public int MeryGetir(Mery mery)
        {
            return mery.Age +5;
        }

        public void Tirman(Mery mery)
        {
            Console.WriteLine(nameof(Mery) + "tirmandı");
        }
    }

    public interface IAgacaTirman
    {
        void Tirman(Mery mery);
    }
}
