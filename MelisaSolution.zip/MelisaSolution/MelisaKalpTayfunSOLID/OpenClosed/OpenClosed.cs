﻿using MelisaKalpTayfunSOLID.InterfaceSegregation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MelisaKalpTayfunSOLID.OpenClosed
{

    //Open-Closed : Geliştirmeye açık, değişime kapalı 
    public abstract class Cisim
    {
        public int a { get; set; }
        public abstract int AlanHesapla();
    }

    public class Kare : Cisim
    {
        public override int AlanHesapla()
        {
            return a * a;
        }
    }

    public class Dikdortgen : Cisim
    {
        public int b { get; set; }

        public override int AlanHesapla()
        {
            return a * b;
        }

        public int DikdortgenABC() //Cisime özel değildir.
        {
            return a * b;
        }
    }

    public class Hesapla
    {
        public int HesaplamaYap(Cisim cisim /*Liskov Prensibi yerine kullanabilme çünkü kare ve dikdörtgen cisimden türemiştir. 
           Ekstra Dependency Inversion uyguluyoruz çünkü bağımlılık artık kare ve dikdörtgenden çıktı*/)
        {
           return cisim.AlanHesapla();
        }
        //public int HesaplamaYap(Kare cisim) //HATALI
        //{
        //    return cisim.AlanHesapla();
        //}
        //public int HesaplamaYap(Dikdortgen cisim) //HATALI
        //{
        //    return cisim.AlanHesapla();
        //}
        //public int HesaplamaYap(Ücgen cisim) //HATALI
        //{
        //    return cisim.AlanHesapla();
        //}
    }

}