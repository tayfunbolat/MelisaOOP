﻿// See https://aka.ms/new-console-template for more information
using MelisaKalpTayfunSOLID;
using MelisaKalpTayfunSOLID.InterfaceSegregation;
using MelisaKalpTayfunSOLID.OpenClosed;

Console.WriteLine("Hello, World!");

//Single Responsibility
MelisaKalpTayfunSOLID.Kare kare = new ();
kare.a = 2;
KareAlanHesapla kareAlanHesapla = new KareAlanHesapla();
int kareAlan = kareAlanHesapla.AlanHesapla(kare);
Console.WriteLine(kareAlan);


MelisaKalpTayfunSOLID.Dikdortgen dikdortgen = new();
dikdortgen.a = 2;
dikdortgen.b = 3;
DikdortgenHesapla dikdortgenHesapla = new DikdortgenHesapla();
int dikdortgenAlan = dikdortgenHesapla.AlanHesapla(dikdortgen);
Console.WriteLine(dikdortgenAlan);



//var tayfun = "tayfun";
//var doublesayi = 14.5;

//Open-Closed
Hesapla hesapla = new Hesapla();
int kareHesap = hesapla.HesaplamaYap(new MelisaKalpTayfunSOLID.OpenClosed.Kare { a=5}); //Liskov uygula
Console.WriteLine(kareHesap);
var dikdortgenHesap = hesapla.HesaplamaYap(new MelisaKalpTayfunSOLID.OpenClosed.Dikdortgen { a = 5,b=6 }); //Liskov uygulama
Console.WriteLine(dikdortgenHesap);


//MelisaKalpTayfunSOLID.OpenClosed.Kare kare1 = new MelisaKalpTayfunSOLID.OpenClosed.Kare();
//kare1.a = 5;
//kare1.AlanHesapla();

//MelisaKalpTayfunSOLID.OpenClosed.Dikdortgen dikdortgen1 = new MelisaKalpTayfunSOLID.OpenClosed.Dikdortgen();
//dikdortgen1.a = 5;
//dikdortgen1.b = 4;
//dikdortgen1.AlanHesapla();


//Ferrari ferrari1 = new Ferrari();
//ferrari1.GazaBas();
//ferrari1.GazaBas();
//ferrari1.GazaBas();
//ferrari1.GazaBas();

//ferrari1.GazaBas();
//ferrari1.GazaBas();
//ferrari1.GazaBas();
//ferrari1.GazaBas();
//ferrari1.NitroModAktifEt();


//Tofas tofas1 = new Tofas();
//tofas1.GazaBas();
//tofas1.vitesDegistir();


AracHareketleri ferrari = new AracHareketleri(new Ferrari());
ferrari.HareketEttir();
AracHareketleri tofas = new AracHareketleri(new Tofas());
tofas.HareketEttir();

Console.ReadLine();