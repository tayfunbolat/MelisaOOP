﻿namespace MelisaKalpTayfunSOLID
{

    public interface IMatematik
    {
        public int Topla(int a, int b);

        public int Bolme(int a, int b);

        public int Cikarma(int a, int b);

        public int Carpma(int a, int b);

    }
    public class Matematik:IMatematik
    {
        //public int MyProperty { get; set; }
        public int Topla(int a, int b)
        {
            return a + b;
            
        }
        public int Bolme(int a, int b)
        {
            return a / b;
        }
        public int Cikarma(int a, int b)
        {
            return a - b;
        }
        public int Carpma(int a, int b)
        {
            return a * b;
        }

    }
    public abstract class Cisim
    {
         public int a { get; set; }
    }
    public class Kare:Cisim
    {

    }
    public class KareAlanHesapla
    {
        public int AlanHesapla(Kare kare)
        {
            return kare.a * kare.a;
        }
    }
    public class Dikdortgen: Cisim    
    {
        public int b { get; set; }

    }
    public class DikdortgenHesapla
    {
        public int AlanHesapla(Dikdortgen dikdortgen)
        {
            return dikdortgen.a * dikdortgen.b;
        }
    }
}
