﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MelisaOOP.Ateş
{
    public interface IAtesFirlat
    {
        string Atesfirlat();
        string Yak();
    }
}
