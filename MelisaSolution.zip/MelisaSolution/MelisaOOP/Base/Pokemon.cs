﻿namespace MelisaOOP.Base
{
    public abstract class Pokemon
    {
        public  string? Adi { get; protected set; }
        public int? Numarasi { get; protected set; }
        public  string? Type { get; protected set; }

        public abstract void Vur();
    }
}

