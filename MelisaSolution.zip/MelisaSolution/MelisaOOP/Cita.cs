﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MelisaOOP.BaseClass;
using MelisaOOP.Interface;

namespace MelisaOOP
{
    //public --genel erişim tüm projenin her yerinden erişim sağlar
    //private -- özel sadece kendi içerisinde erişim var.
    //internal -- Aynı proje içerisinden erişim sağlar dışarı kapalıdır.
    //protected -- Miras alınan sınıf içerisinde erişime açıktır
    //


    /*Abstraction : Tüm class yapılarında ortak olan fonksiyonların veya işlemlerin en üst tabaka da birleştirilmesidir. Böylece classlar tek bir ortak yerden
    /özelliğe erişilebilir */

    public class Cita : Hayvan, ITirmanmak
    {
        public void AgacaTirman()
        {
            throw new NotImplementedException();
        }

        public override void Beslenme()
        {
            Console.WriteLine("Çita Beslendi");
        }
    }

}

