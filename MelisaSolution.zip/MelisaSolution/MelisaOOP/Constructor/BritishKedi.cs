﻿namespace MelisaOOP.Constructor
{
    public class britishKedi : Kedi
    {
        public britishKedi()  //constructor
        {
            Cinsiyet = "British";
        }
        public britishKedi(string cinsiyet)  //constructor
        {
        }
        //Polymorphism uyguladık.
        public override void RenkGetir()
        {
            Console.WriteLine("Duman Rengi");
        }
        //Saygılar.
    }

}
