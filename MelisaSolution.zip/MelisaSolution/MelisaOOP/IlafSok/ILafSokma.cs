﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MelisaOOP.ILafSok
{
    public interface ILafSokma
    {
        string LafSok();
        string Agresifleşme();

        string GerilerekLafSokma(int darbe);

    }
}
