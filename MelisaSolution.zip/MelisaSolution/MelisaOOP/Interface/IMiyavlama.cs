﻿namespace MelisaOOP.Interface
{
    //Inheritance(Kalıtım) : 
    public interface IMiyavlama
    {
        public void miyavDe();
    }

}
