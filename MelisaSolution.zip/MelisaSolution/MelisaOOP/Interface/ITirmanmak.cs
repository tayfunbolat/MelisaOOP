﻿namespace MelisaOOP.Interface
{

    //Inheritance(Kalıtım) : 
    public interface ITirmanmak
    {
        public void AgacaTirman();
    }
}
