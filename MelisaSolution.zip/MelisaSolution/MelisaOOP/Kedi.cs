﻿using MelisaOOP.BaseClass;
using MelisaOOP.Interface;

namespace MelisaOOP
{
    //public --genel erişim tüm projenin her yerinden erişim sağlar
    //private -- özel sadece kendi içerisinde erişim var.
    //internal -- Aynı proje içerisinden erişim sağlar dışarı kapalıdır.
    //protected -- Miras alınan sınıf içerisinde erişime açıktır
    //


    /*Abstraction : Tüm class yapılarında ortak olan fonksiyonların veya işlemlerin en üst tabaka da birleştirilmesidir. Böylece classlar tek bir ortak yerden
    /özelliğe erişilebilir */

    public class Kedi : Hayvan, IMiyavlama, ITirmanmak
    {
        public string cinsiyett; //fiedl
        public string Cinsiyet { get; protected set; } //Kapsülleme auto property

        public void AgacaTirman()
        {
            Console.WriteLine($"ucarak tırman");
        }

        public virtual void RenkGetir()
        {
            Console.WriteLine("Saf beyaz renk");

        }

        //Overload method
        public void AgacaTirman(string tip)
        {
            Cinsiyet = tip + "British";
            Console.WriteLine($"{tip} ucarak tırman"); // string.format
        }

        public override void Beslenme()
        {
            Console.WriteLine("Kedi Beslendi");
        }

        public void miyavDe()
        {
            throw new NotImplementedException();
        }
    }

}

