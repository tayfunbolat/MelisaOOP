﻿using MelisaOOP.BaseClass;

namespace MelisaOOP
{
    //public --genel erişim tüm projenin her yerinden erişim sağlar
    //private -- özel sadece kendi içerisinde erişim var.
    //internal -- Aynı proje içerisinden erişim sağlar dışarı kapalıdır.
    //protected -- Miras alınan sınıf içerisinde erişime açıktır
    //


    /*Abstraction : Tüm class yapılarında ortak olan fonksiyonların veya işlemlerin en üst tabaka da birleştirilmesidir. Böylece classlar tek bir ortak yerden
    /özelliğe erişilebilir */
    public class Köpek : Hayvan
    {
        public override void Beslenme()
        {
            Console.WriteLine("Köpek Beslendi");
        }
    }
}

