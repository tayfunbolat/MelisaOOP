﻿using MelisaOOP.Base;
using MelisaOOP.ILafSok;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace MelisaOOP.Ateş
{
    public class Melisa : Pokemon, IAtesFirlat, ILafSokma
    {
        public Melisa()
        {
        }

        public Melisa(int? numarasi,string Type,string adi)
        {
            Numarasi = numarasi;
            this.Type = Type;
            Adi = adi;
        }
        public string Agresifleşme()
        {
            return "Melisa Agresifleşti";
        }

        public string Atesfirlat()
        {
            return "Melisa Ateş Fırlatır";
        }

        public string GerilerekLafSokma(int darbe)
        {
            return $"MELİSA Gerilerek {darbe}  Laf sokar";
        }

        public string LafSok()
        {
            return "MELİSA Öfkeli Laf Soktu";
        }


        public override void Vur()
        {
            Console.WriteLine("Melisa tayfun'a vurur");
        }

        public string Yak()
        {
            return "MELİSA Yakıp Yıkar";
        }
    }
}
