﻿using MelisaOOP.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MelisaOOP.Ateş
{
    public class Squirtle : Pokemon, ISuFirlat, ISuFiskirt
    {
        public Squirtle()
        {
            Numarasi = 1;
            Type = "SU Pokemon";
            Adi = nameof(Squirtle);
        }
        public string SuFirlat()
        {
            return "Su Firlatti";
        }

        public string SuFiskirtmaSaldirisi()
        {
            return "Squirtle SuFiskirtmaSaldirisi";
        }

        public string Sula()
        {
            return "Squirtle SuFiskirtmaSaldirisi";
        }

        public override void Vur()
        {
            Console.WriteLine("Squirtle Vurdu");
        }
    }
}
