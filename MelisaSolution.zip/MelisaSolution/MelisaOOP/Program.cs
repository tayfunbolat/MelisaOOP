﻿// See https://aka.ms/new-console-template for more information
using MelisaOOP;
using MelisaOOP.Ateş;
using MelisaOOP.BaseClass;
using MelisaOOP.Constructor;

Console.WriteLine("Hello, World!");


//Hayvan köpek = new Köpek();
//köpek.Beslenme();

//Kedi kedi = new Kedi();
//kedi.RenkGetir();
//kedi.Beslenme();
//kedi.AgacaTirman();
//kedi.AgacaTirman("zıplayıp");

//Cita cita = new Cita();
//cita.Beslenme();



//britishKedi britishKedi = new britishKedi(); //oluşturma ilk classı boş constructor
//britishKedi.RenkGetir();
//Console.WriteLine(britishKedi.Cinsiyet);

//britishKedi britishKedi2 = new britishKedi("erkek"); //oluşturma ilk classı parametreli constructor
//Console.WriteLine(britishKedi2.Cinsiyet);

//Console.ReadLine();


Melisa melisa = new Melisa(100,"İkizler","Melisa");
melisa.Vur();
Console.WriteLine(melisa.Agresifleşme());
//melisa.Numarasi = 15;
Console.WriteLine(melisa.GerilerekLafSokma(100));

Console.WriteLine(melisa.Atesfirlat());

Console.ReadLine();
