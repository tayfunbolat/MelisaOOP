﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MelisaOOP.Ateş
{
    public interface ISuFirlat
    {
        string SuFirlat();
        string Sula();
    }
}
